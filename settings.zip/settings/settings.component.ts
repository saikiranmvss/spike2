import { Component } from '@angular/core';
import { fadeInAnimation } from '../login/login.component';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  animations: [fadeInAnimation],
  host: { '[@fadeInAnimation]': '' },
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent {

}