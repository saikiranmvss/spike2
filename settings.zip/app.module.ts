import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SettingsComponent } from './settings/settings.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RouterModule } from '@angular/router';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SettingsComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    RouterModule.forRoot([
      {path: 'settings', component: SettingsComponent , data: { animationState: 'One' }},
      {path: 'dashboard', component: DashboardComponent  ,data: { animationState: 'Two' } },
      {path: '', component: LoginComponent , data: { animationState: 'Three' } },
    ]),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
  
 }
 

